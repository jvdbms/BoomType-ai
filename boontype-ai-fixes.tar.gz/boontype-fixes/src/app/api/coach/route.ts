import { NextRequest, NextResponse } from 'next/server';

const SYSTEM_PROMPT = `You are an expert AI typing coach for "mboomtype-ai", the world's first AI-integrated typing tutor. Your role is to help users improve their typing speed and accuracy through personalized coaching.

Your expertise includes:
- Touch typing technique and proper finger placement
- Speed improvement strategies
- Accuracy improvement methods
- Ergonomic best practices
- Common typing error patterns and how to fix them
- Practice routine recommendations

When responding:
- Be concise but helpful
- Reference the user's specific performance data when provided
- Give actionable, practical advice
- Use encouraging language
- Suggest specific exercises when relevant
- Break down complex advice into simple steps

Analyze the user's performance metrics (WPM, accuracy, error patterns) and provide targeted recommendations.`;

export async function POST(request: NextRequest) {
  try {
    const { message, personality, performanceData, chatHistory } = await request.json();

    if (!message || typeof message !== 'string') {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 });
    }

    const apiKey = process.env.OPENAI_API_KEY || process.env.ANTHROPIC_API_KEY;

    if (!apiKey) {
      // Fallback: return a helpful static response if no API key is configured
      const fallback = getFallbackResponse(message, performanceData);
      return NextResponse.json({ reply: fallback });
    }

    const personalityModifier = {
      encouraging: 'Be warm, supportive, and motivating. Celebrate progress and frame challenges as opportunities.',
      technical: 'Be precise, data-driven, and analytical. Focus on biomechanics, technique, and measurable improvements.',
      casual: 'Be friendly, relaxed, and conversational. Use everyday language and keep things light.',
    }[personality as string] || 'Be warm, supportive, and motivating.';

    const systemPrompt = `${SYSTEM_PROMPT}\n\nCoaching personality: ${personalityModifier}`;

    const messages: Array<{ role: string; content: string }> = [
      { role: 'system', content: systemPrompt },
    ];

    if (performanceData) {
      const perfStr = `Current user performance data:
- Average WPM: ${performanceData.avgWpm || 'N/A'}
- Average Accuracy: ${performanceData.avgAccuracy || 'N/A'}%
- Total Sessions: ${performanceData.totalSessions || 0}
- Total Practice Time: ${performanceData.totalTime ? Math.round(performanceData.totalTime / 60) : 0} minutes
- Weak Keys: ${performanceData.weakKeys || 'Not enough data yet'}
- Recent WPM Trend: ${performanceData.recentWpm || 'N/A'}`;
      messages.push({ role: 'system', content: perfStr });
    }

    if (chatHistory && Array.isArray(chatHistory)) {
      for (const msg of chatHistory.slice(-10)) {
        messages.push({ role: msg.role, content: msg.content });
      }
    }

    messages.push({ role: 'user', content: message });

    // Support both OpenAI and Anthropic APIs
    if (process.env.ANTHROPIC_API_KEY && !process.env.OPENAI_API_KEY) {
      // Use Anthropic API
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': process.env.ANTHROPIC_API_KEY,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: 'claude-haiku-4-5-20251001',
          max_tokens: 500,
          system: systemPrompt,
          messages: messages.filter(m => m.role !== 'system'),
        }),
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || 'I apologize, I could not generate a response. Please try again.';
      return NextResponse.json({ reply });
    } else {
      // Use OpenAI-compatible API
      const res = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages,
          max_tokens: 500,
          temperature: 0.7,
        }),
      });
      const data = await res.json();
      const reply = data.choices?.[0]?.message?.content || 'I apologize, I could not generate a response. Please try again.';
      return NextResponse.json({ reply });
    }
  } catch (error) {
    console.error('AI Coach error:', error);
    return NextResponse.json(
      { reply: "I'm having trouble connecting right now. Please try again in a moment." },
      { status: 200 }
    );
  }
}

function getFallbackResponse(message: string, performanceData?: Record<string, unknown>): string {
  const msg = message.toLowerCase();

  if (msg.includes('wpm') || msg.includes('speed') || msg.includes('fast')) {
    const wpm = performanceData?.avgWpm;
    if (wpm && Number(wpm) < 40) {
      return "To improve your speed, focus on accuracy first — don't rush! Practice the home row keys daily: ASDF and JKL;. Try 10-minute sessions with easy lessons before pushing for speed.";
    }
    return "Great focus on speed! Try timed drills — aim for 1-minute bursts at full effort, then rest. Consistency beats intensity. Practice common word patterns and don't look at your hands!";
  }

  if (msg.includes('accuracy') || msg.includes('mistake') || msg.includes('error')) {
    return "For better accuracy: slow down slightly and focus on hitting each key cleanly. Identify your problem keys in the Analytics tab and drill those specifically. Accuracy above 95% should always come before speed gains.";
  }

  if (msg.includes('finger') || msg.includes('position') || msg.includes('hand')) {
    return "Proper finger placement is key: left hand covers ASDF, right hand covers JKL;. Your thumbs rest on the spacebar. Never look at the keyboard — trust muscle memory. Curved fingers, light touch!";
  }

  if (msg.includes('practice') || msg.includes('routine') || msg.includes('schedule')) {
    return "A solid routine: 15–20 minutes daily beats 2 hours once a week. Start with warm-up drills, then tackle lessons slightly above your comfort zone. End each session reviewing your weak keys.";
  }

  return "Keep practicing consistently — even 15 minutes a day makes a huge difference! Check your Analytics tab to see your progress and identify which keys need the most attention. You're doing great!";
}
